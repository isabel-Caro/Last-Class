package com.example.ejemplo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ejemplo.adaptadores.PersonajeAdaptador;
import com.example.ejemplo.clases.Personaje;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Personaje> listaPersonaje = new ArrayList<>();

    RecyclerView rcv_personajes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv_personajes = findViewById(R.id.rcv_personajes);

        cargarInformacion();

    }

    public void cargarInformacion() {
        String url = "https://rickandmortyapi.com/api/character";

        // metodos http (SET, GET, POST)
        StringRequest myRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    recibirRespuesta(new JSONObject(response));
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Error en el servidor", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Error en el servidor", Toast.LENGTH_LONG).show();
            }
        });


        RequestQueue rg = Volley.newRequestQueue(getApplicationContext());
        rg.add(myRequest);



    }

    public void recibirRespuesta(JSONObject respuesta) {
        // siempre utilizar un try-catch para un jsonObject
        try {

            for (int i=0; i<=respuesta.getJSONArray("results").length(); i++){
                String nombre = respuesta.getJSONArray("results").getJSONObject(i).getString("name");
                String estado = respuesta.getJSONArray("results").getJSONObject(i).getString("status");
                String especie = respuesta.getJSONArray("results").getJSONObject(i).getString("species");
                String imagen = respuesta.getJSONArray("results").getJSONObject(i).getString("image");


                Personaje p = new Personaje(nombre, estado, especie, imagen);

                listaPersonaje.add(p);



            }

            rcv_personajes.setLayoutManager(new LinearLayoutManager(this));
            rcv_personajes.setAdapter(new PersonajeAdaptador(listaPersonaje));



        }catch (JSONException e){
            Toast.makeText(getApplicationContext(), "Error en el servidor", Toast.LENGTH_LONG).show();
        }
    }
}